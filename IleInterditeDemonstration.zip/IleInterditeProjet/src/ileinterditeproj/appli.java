/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ileinterditeproj;

import Vues.VuePlateau;
import Vues.VueTuile;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author kemplail
 */
public class appli {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Controleur_ScenarioVictoire c = new Controleur_ScenarioVictoire(); //test scénario Victoire
        
        //Controleur_ScenarioTresorsPerdu c = new Controleur_ScenarioTresorsPerdu ();
        
        //Controleur_ScenarioDefaiteHeliport c = new Controleur_ScenarioDefaiteHeliport(); //test scénario defaite
        
         //Controleur c = new Controleur(); jeux normal avec choix de difficulté et paramétre aléatoire
        
      
    }
    
}
