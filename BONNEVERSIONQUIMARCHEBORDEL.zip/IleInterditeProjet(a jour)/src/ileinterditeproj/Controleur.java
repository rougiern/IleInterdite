/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ileinterditeproj;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;

/**
 *
 * @author kemplail
 */
public class Controleur implements Observer {

    private Grille grille;
    private ArrayList<Aventurier> joueurs;
    private ArrayList<Tuile> tuilesdepart;
    private VueAventurier vueaventurier;
    private int compteurtour = 0;
   
    Controleur() {
        
        grille = new Grille();
        ArrayList<Tuile> lestuiles = new ArrayList();
        Tuile t1 = new Tuile("Le Pont des Abimes");
        Tuile t2 = new Tuile("La Porte de Bronze"); t2.setEtat(EtatTuile.Inondee); // Pion.ROUGE
        Tuile t3 = new Tuile("La Caverne des Ombres");
        Tuile t4 = new Tuile("La Porte de Fer" );    //Pion.VIOLET
        Tuile t5 = new Tuile("La Porte d'Or");   //Pion.JAUNE
        Tuile t6 = new Tuile("Les Falaises de l'Oubli");
        Tuile t7 = new Tuile("Le Palais de Corail");
        Tuile t8 = new Tuile("La Porte d'Argent");  //Pion.ORANGE
        Tuile t9 = new Tuile("Les Dunes de l’Illusion"); t9.setEtat(EtatTuile.Coulee);
        Tuile t10 = new Tuile("Heliport");      //Pion.BLEU 
        Tuile t11= new Tuile("La Porte de Cuivre");  // Pion.VERT
        Tuile t12 = new Tuile("Le Jardin des Hurlements"); 
        Tuile t13 = new Tuile("La Foret Pourpre");
        Tuile t14 = new Tuile("Le Lagon Perdu"); t14.setEtat(EtatTuile.Inondee);
        Tuile t15 = new Tuile("Le Marais Brumeux"); t15.setEtat(EtatTuile.Coulee);
        Tuile t16 = new Tuile("Observatoire"); t16.setEtat(EtatTuile.Inondee);
        Tuile t17 = new Tuile("Le Rocher Fantome"); t17.setEtat(EtatTuile.Coulee);
        Tuile t18 = new Tuile("La Caverne du Brasier"); t18.setEtat(EtatTuile.Inondee);
        Tuile t19 = new Tuile("Le Temple du Soleil");
        Tuile t20 = new Tuile("Le Temple de La Lune"); t20.setEtat(EtatTuile.Coulee);
        Tuile t21 = new Tuile("Le Palais des Marees");
        Tuile t22 = new Tuile("Le Val du Crepuscule");
        Tuile t23 = new Tuile("La Tour du Guet");
        Tuile t24 = new Tuile("Le Jardin des Murmures"); t24.setEtat(EtatTuile.Inondee);
        
        tuilesdepart = new ArrayList();
        
        tuilesdepart.add(t2);
        tuilesdepart.add(t4);
        tuilesdepart.add(t5);
        tuilesdepart.add(t8);
        tuilesdepart.add(t10);
        tuilesdepart.add(t11);
        
        lestuiles.add(t1);
        lestuiles.add(t2);
        lestuiles.add(t3);
        lestuiles.add(t4);
        lestuiles.add(t5);
        lestuiles.add(t6);
        lestuiles.add(t7);
        lestuiles.add(t8);
        lestuiles.add(t9);
        lestuiles.add(t10);
        lestuiles.add(t11);
        lestuiles.add(t12);
        lestuiles.add(t13);
        lestuiles.add(t14);
        lestuiles.add(t15);
        lestuiles.add(t16);
        lestuiles.add(t17);
        lestuiles.add(t18);
        lestuiles.add(t19);
        lestuiles.add(t20);
        lestuiles.add(t21);
        lestuiles.add(t22);
        lestuiles.add(t23);
        lestuiles.add(t24);
     
        grille.setTableau(lestuiles);
        
        joueurs = new ArrayList();
        setJoueurs();
        
        
          
               vueaventurier = new VueAventurier(this.getJoueurs().get(compteurtour).getNom(),this.getJoueurs().get(compteurtour).getClass().getSimpleName() ,this.getJoueurs().get(compteurtour).getPion().getCouleur() );
               vueaventurier.addObserver(this);
        
    }
    
    @Override
    public void update(Observable arg0, Object arg1) {
        
        if(arg1 instanceof Message){
            Message message = (Message) arg1 ;
            if(message.getAction()==Action.DEPLACER){
                
                int i = 0;
                while(i<joueurs.size() && !(joueurs.get(i).getNom().equals(message.getNomJ()))){
                    i++;
                }
                
                Grille g = this.getGrille();
                Scanner sc = new Scanner(System.in) ;
                ArrayList<Tuile> tuilesatteignables;
                
                if (!(joueurs.get(i) instanceof Pilote)) {
                
                tuilesatteignables = joueurs.get(i).seDeplacer(grille);
                
                }
                
                else {
                    
                    System.out.println("Voulez-vous utiliser votre vol ?");
                    String rep = sc.nextLine();
                    if (rep.equals("oui")) {
                        tuilesatteignables = ((Pilote)joueurs.get(i)).seDeplacerVol(grille);
                    } else {
                        tuilesatteignables = joueurs.get(i).seDeplacer(grille);
                    }
                    
                }
                 
                if (tuilesatteignables.isEmpty() == false) {
                
                affichernomtuiles(tuilesatteignables);
                 
                 System.out.println("Ou se déplacer ?");
                 String nomtuile = sc.nextLine();
                 Tuile nouvelletuile = chercherTuile(nomtuile,tuilesatteignables);
                 
                 if(nouvelletuile != null){
                     joueurs.get(i).changerTuileCourante(nouvelletuile);
                     System.out.println("Action effectuée : Nouvelle tuile :"+joueurs.get(i).getTuileCourante().getNom());
                 }
                 
                }else {
                    System.out.println("Action impossible");
                }
                
            }
            
            else if(message.getAction() == Action.ASSECHER) {
                
                int i = 0;
                while ((i < joueurs.size()) && (!(joueurs.get(i).getNom().equals(message.getNomJ())))) {
                    i++; 
                }
                
                    Grille g = this.getGrille();
                    ArrayList<Tuile> tuilesassechables = joueurs.get(i).assecher(grille);
                    
                    if (tuilesassechables.isEmpty() == false) {
                   
                    affichernomtuiles(tuilesassechables);
                        
                    System.out.println("Quelle case assécher ?");
                    Scanner sc = new Scanner(System.in) ;
                    String nomtuile = sc.nextLine();
                    Tuile tuileassecher = chercherTuile(nomtuile,tuilesassechables);
                    
                    if (tuileassecher != null) {
                       joueurs.get(i).assechertuile(tuileassecher);
                       System.out.println("Action effectuée : Tuile assechée :"+tuileassecher.getNom());
                    } 
                    
                    if (joueurs.get(i) instanceof Ingenieur) {
                    
                    System.out.println("Voulez-vous assécher une autre case ?");
                    String rep = sc.nextLine();
                    
                    if(rep.equals("oui") ) {
                     
                    tuilesassechables = joueurs.get(i).assecher(grille);
                    
                   
                    if (tuilesassechables.isEmpty() == false) {
                    
                    affichernomtuiles(tuilesassechables);
                    
                    System.out.println("Quelle case assécher ?");
                    sc = new Scanner(System.in) ;
                    nomtuile = sc.nextLine();
                    tuileassecher = chercherTuile(nomtuile,joueurs.get(i).seDeplacer(grille));
                        if (tuileassecher != null) {
                            ((Ingenieur)joueurs.get(i)).assechertuile2efois(tuileassecher);
                            System.out.println("Action effectuée : Tuile assechée :"+tuileassecher.getNom());
                            }else{
                            System.out.println("Assechement impossible");
                            }
                    }else {
                        System.out.println("Assechement impossible");
                    }
                    }
          
                    }
                    
                 } else {
                        System.out.println("Assechement impossible");
                    }
        
             }
        
            else if ((message.getAction() ==Action.BOUGERJOUEUR)) {
                
                 int i = 0;
                while ((i < joueurs.size()) && (!(joueurs.get(i).getNom().equals(message.getNomJ())))) {
                    i++; 
                }
                
                int nbActions = joueurs.get(i).getPtsaction();
                Grille g = this.getGrille();
                
                if (joueurs.get(i) instanceof Navigateur && nbActions > 0) {
                    
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Entrez le nom du joueur");
                    String nomjoueuradeplacer = sc.nextLine();
                    
                    Aventurier av = chercherAventurier(nomjoueuradeplacer);
                    
                    if (av != null) {  
                        ArrayList<Tuile> tuilesatteignables = av.deplacementParNavigateur(g);
                            if (tuilesatteignables.isEmpty() == false) {
                
                                affichernomtuiles(tuilesatteignables);
                 
                                System.out.println("Ou le déplacer ?");
                                String nomtuile = sc.nextLine();
                                Tuile nouvelletuile = chercherTuile(nomtuile,tuilesatteignables);
                 
                                 if(nouvelletuile != null){
                                 joueurs.get(i).changerTuileCourante(nouvelletuile);
                                 joueurs.get(i).enleveUneAction();
                                 System.out.println("Action effectuée : Nouvelle tuile :"+joueurs.get(i).getTuileCourante().getNom());
                                 }
                            }else {
                               System.out.println("Action impossible");
                            }
                        
                        
                    }
                    
                }
                
            } else if(message.getAction() == Action.TERMINERTOUR) {
               compteurtour++;
                if (compteurtour < joueurs.size()) {
                    vueaventurier.close();
                    vueaventurier = new VueAventurier(this.getJoueurs().get(compteurtour).getNom(),this.getJoueurs().get(compteurtour).getClass().getSimpleName() ,this.getJoueurs().get(compteurtour).getPion().getCouleur() );
                    vueaventurier.addObserver(this);
                } else {
                    System.out.println("Le tour est terminé");
                    compteurtour = 0;
                    
                    for (Aventurier j : joueurs) {
                        j.setPtsaction(3);
                        if (j instanceof Pilote) {
                            ((Pilote) j).setNbvol(1);
                        }
                    }
                    
                    vueaventurier = new VueAventurier(this.getJoueurs().get(compteurtour).getNom(),this.getJoueurs().get(compteurtour).getClass().getSimpleName() ,this.getJoueurs().get(compteurtour).getPion().getCouleur() );
                    vueaventurier.addObserver(this);
                    
                }
            }
            
        }
            
    }
    
    public void addAventurier(Aventurier aventurier) {
        
        if (this.getJoueurs().size() < 4) {
        this.getJoueurs().add(aventurier); }
    }

    /**
     * @return the grille
     */
    public Grille getGrille() {
        return grille;
    }

    /**
     * @return the joueurs
     */
    public ArrayList<Aventurier> getJoueurs() {
        return joueurs;
    }
    
    public void afficherJoueurs(){
        
        for (Aventurier j: joueurs){
            
            System.out.println("Nom :"+j.getNom()+" Role:"+j.getClass().getSimpleName());
            
        }
       
    }
    
    public void afficherGrille(){
        int i = 1;
        for (int x=0; x<6;x++){
            for (int y=0;y<6;y++){
                System.out.println("Tuiles n°"+i+"="+grille.getTableau()[x][y].getNom());
                i++;
                
            }
       }
    
    }

    /**
     * @param joueurs the joueurs to set
     */
    public void setJoueurs() {
        System.out.println("Combien y a t'il de joueurs ?");
        Scanner sc = new Scanner(System.in) ;
        int nbJ = sc.nextInt();
        while (nbJ >4 || nbJ < 2 ) {
             
             System.out.println("Le nombre de joueurs doit être compris entre 2 et 4 inclus");
             nbJ = sc.nextInt();
        }
        for(int i = 0 ; i<nbJ ; i++){
            System.out.println("Entrez votre nom");
            String nom = sc.next();
            System.out.println("Entrez votre role");
            String role = sc.next();
            while ( role.equals("plongeur")==false && role.equals("messager")==false && role.equals("navigateur")==false && role.equals("explorateur")==false && role.equals("ingenieur")==false && role.equals("pilote")==false ) {
               System.out.println("Le role n'existe pas veuillez choisir un role valide ");
               role = sc.nextLine();
            }
            if(role.equals("plongeur")){
                Plongeur p = new Plongeur(nom,tuilesdepart.get(1)); //Noir
                joueurs.add(p);
            }else if(role.equals("messager")){
                Messager m = new Messager(nom,tuilesdepart.get(3));  //Blanc
                joueurs.add(m);
            }else if(role.equals("navigateur")){
                Navigateur n = new Navigateur(nom,tuilesdepart.get(2)); // Jaune
                joueurs.add(n);
            }else if(role.equals("pilote")){
                Pilote pilote = new Pilote(nom,tuilesdepart.get(4)); // Bleu
                joueurs.add(pilote);
            }else if(role.equals("ingenieur")){
                  // Pion.ROUGE
                Ingenieur ing = new Ingenieur(nom,tuilesdepart.get(0)); //Rouge
                joueurs.add(ing);
            }else if(role.equals("explorateur")){
                Explorateur exp = new Explorateur(nom,tuilesdepart.get(5)); //Vert
                joueurs.add(exp);
            }
            
        }
        
    }

    public Tuile chercherTuile(String nomtuile, ArrayList<Tuile> tuilesatteignable) {
        int i =0;
        Tuile tvoulu = null;
        while(i<tuilesatteignable.size() && tuilesatteignable.get(i).getNom().equals(nomtuile)==false){
           i++;
        }
         if(i<tuilesatteignable.size() && tuilesatteignable.get(i).getNom().equals(nomtuile) ){
             tvoulu = tuilesatteignable.get(i) ;
         }
         
         return tvoulu;
        
    }
    
    public Aventurier chercherAventurier(String nomjoueurcherche) {
        int i =0;
        Aventurier jvoulu = null;
        while(i<joueurs.size() && joueurs.get(i).getNom().equals(nomjoueurcherche)==false){
           i++;
        }
         if(i<joueurs.size() && joueurs.get(i).getNom().equals(nomjoueurcherche) ){
             jvoulu = joueurs.get(i) ;
         }
         
         return jvoulu;
        
    }
    
    private void affichernomtuiles(ArrayList<Tuile> listetuiles) {
        for (Tuile t : listetuiles) {
            System.out.println(t.getNom());
        }
    }
    
}